import {Tab} from './util/Tab.js'
import {注册自定义tab} from './util/regist.js'
import {BrowserTab} from './browserTab/index.js'
注册自定义tab("BrowserTab",BrowserTab)
export {Tab as Tab} 
export  {注册自定义tab} from './util/regist.js'
